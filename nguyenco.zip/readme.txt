HELLO Mr or Mrs grader!
My name is coulby nguyen 932-439-525

this is the instruction to compile my program and run the grading script!

to compile my program simply type the following code into the terminal!
vvvvvvvvvvvvvvvvvvvvvvvvvv
gcc smallsh.c -o smallsh
^^^^^^^^^^^^^^^^^^^^^^^^^^

after that line, the code will be compiled and ready to execute!
yeah after that you should be able to run the grading script!
idk if the instructions said to write that line of code in here
but i dont want to docked points for not having it so just in case

vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
p3gradingscript > mytestresults 2>&1
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

or

vvvvvvvvvvvvvvvvvvvvv
p3gradingscript 2>&1
^^^^^^^^^^^^^^^^^^^^^

p.s. sorry if i sound condescending I'm going on like hour 20 with no sleep!
